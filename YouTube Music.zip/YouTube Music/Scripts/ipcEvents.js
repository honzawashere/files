const { navigatePageBack } = require("./Events/navigatePageBack")
const { titlebarControls } = require("./Events/titlebarControls")
const { log } = require("./logger")

module.exports.setupIPCRemote = () => {
    navigatePageBack()
    titlebarControls()

    log(`ipcEvents: ipcRemote has been started`)
}