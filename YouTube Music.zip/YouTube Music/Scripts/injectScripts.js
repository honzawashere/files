const { playerDatabase } = require("./databaseManager")
const { log } = require("./logger")

module.exports.injectScripts = (window) => {
    if (!window.webContents.getURL().startsWith("https://music.youtube.com/")) return

    // White logo
    window.webContents.executeJavaScript(`document.querySelector("#left-content > a > picture:nth-child(1) > source:nth-child(1)").srcset = 'https://music.youtube.com/img/white_logo.svg'`).catch(err => { if (err) return })
    window.webContents.executeJavaScript(`document.querySelector("#left-content > a > picture:nth-child(1) > source:nth-child(2)").srcset = 'https://music.youtube.com/img/white_logo.svg'`).catch(err => { if (err) return })
    window.webContents.executeJavaScript(`document.querySelector("#left-content > a > picture:nth-child(1) > img").src = 'https://music.youtube.com/img/white_logo.svg'`).catch(err => { if (err) return })

    // Set "Playback Speed" title to "Playback Speed [Experiment]"
    window.webContents.executeJavaScript('document.querySelector("#right-controls > div > ytmusic-playback-rate-renderer").title = document.querySelector("#right-controls > div > ytmusic-playback-rate-renderer").title + " [Experiment]"')

    // Force to reset title to "YouTube Music"
    window.on("page-title-updated", () => {
        window.setTitle("YouTube Music")
    })

    window.on("enter-full-screen", () => {
        window.setMenuBarVisibility(false)
    })

    window.on("leave-full-screen", () => {
        window.setMenuBarVisibility(true)
    })

    setInterval(() => {
        // Unlock "Lyrics" and "Featured" buttons always
        window.webContents.executeJavaScript([
            `if (document.querySelector("#tabsContent > tp-yt-paper-tab:nth-child(4)")) {`,
            `if (document.querySelector("#tabsContent > tp-yt-paper-tab:nth-child(4)").disabled) {`,
            `document.querySelector("#tabsContent > tp-yt-paper-tab:nth-child(4)").disabled = false`,
            `document.querySelector("#tabsContent > tp-yt-paper-tab:nth-child(4)").ariaDisabled = false`,
            `document.querySelector("#tabsContent > tp-yt-paper-tab:nth-child(4)").style = "pointer-events: default;"`,
            `}`,
            `if (document.querySelector("#tabsContent > tp-yt-paper-tab:nth-child(3)").disabled) {`,
            `document.querySelector("#tabsContent > tp-yt-paper-tab:nth-child(3)").disabled = false`,
            `document.querySelector("#tabsContent > tp-yt-paper-tab:nth-child(3)").ariaDisabled = false`,
            `document.querySelector("#tabsContent > tp-yt-paper-tab:nth-child(3)").style = "pointer-events: default;"`,
            `}`,
            `}`,
        ].join("\n")).catch(err => { if (err) return })
    })

    log(`injectScripts: Injected scripts`)
}