module.exports.log = (message) => {
    console.log(`[YouTube Music] ${message}`)
    return
}