const { ipcRenderer } = require("electron")
const { log } = require("../../Scripts/logger")

module.exports.insertBackButton = () => {
    if (!document.URL.startsWith("https://music.youtube.com")) return
    const backButton = document.createElement("ytmusic-back-button")
    const menu = document.querySelector("#layout > ytmusic-nav-bar > div.center-content.style-scope.ytmusic-nav-bar > ytmusic-pivot-bar-renderer")
    menu.appendChild(backButton)

    const buttonString = document.createElement("yt-formatted-string")
    buttonString.classList.add("tab-title", "style-scope", "ytmusic-pivot-bar-item-renderer")

    backButton.appendChild(buttonString)

    buttonString.innerHTML = "Back"
    buttonString.removeAttribute("is-empty")

    backButton.onclick = () => {
        ipcRenderer.send("navigate-page-back")
        log(`insertBackButton: navigate-page-back sent to ipcMain`)
    }

    log(`insertBackButton: Back button inserted`)
}