module.exports.waitForSettingsOpen = () => {
    const settingsButton = document.querySelector("#items > ytd-compact-link-renderer:nth-child(3)")
    settingsButton.onclick = () => {
        const items = document.querySelector("#items")

        const discord = document.createElement("ytmusic-setting-boolean-renderer")
        items.appendChild(discord)
        discord.id = "plugin-enabled"
        discord.classList.add("style-scope", "ytmusic-setting-category-collection-renderer")

        const discord_iron_label = document.createElement("iron-label")
        discord.appendChild(discord_iron_label)
        discord_iron_label.classList.add("content", "style-scope", "ytmusic-setting-boolean-renderer")

        const discord_title = document.createElement("yt-formatted-string")
        discord_iron_label.appendChild(discord_title)
        
    }
}