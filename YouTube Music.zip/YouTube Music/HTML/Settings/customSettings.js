module.exports.insertCustomSettings = () => {
    
}